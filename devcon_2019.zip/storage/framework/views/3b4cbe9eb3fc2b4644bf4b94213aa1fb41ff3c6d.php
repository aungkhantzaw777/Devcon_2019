<?php $__env->startSection('content'); ?>
<div class="row user-wrap">

    <div class="card w-100">
        <div class="card-header clearfix">
            <span class="float-left">Registeration</span>
            <div class="form-group float-right">
                <form method="POST" id="user-form" action="/dev_con/searchuser">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input class="form-control small" name="keyword" onkeyenter="event.preventDefault();
                        document.getElementById('user-form').submit();" type="text" placeholder="Search for ...">
                        <div class="input-group-append"><button class="btn btn-primary py-0" type="submit"><i class="fas fa-search"></i></button></div>
                    </div>
                    
                    
                </form>
                
            </div>
            
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Ticket ID</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Gender</th>
                    <th scope="col">location</th>
                    <th scope="col">Details</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->ticket_id); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->gender); ?></td>
                    <td><?php echo e($user->location); ?></td>
                    <td><a href="#" class="btn btn-success">Detail</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
            </tbody>
        </table>
        <?php echo e($users->appends(['sort' => 'username'])->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aungkhantzaw\Documents\coding\devcon_2019\resources\views/admin/home.blade.php ENDPATH**/ ?>