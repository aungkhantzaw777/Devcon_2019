<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>
                
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group row">
                            <label for="username" class="col-md-4 col-form-label text-md-right"><?php echo e(__('username')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="username" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="username" value="<?php echo e(old('username')); ?>" autocomplete="username" autofocus>
                                
                                <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>">
                                
                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="Password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" value="<?php echo e(old('password')); ?>">
                                
                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="comfirm password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Comfirm Password')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="comfirm" type="password" class="form-control <?php if ($errors->has('confirm')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('confirm'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password_confirmation" value="<?php echo e(old('confirm')); ?>">
                                
                                
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="Date_of_brith" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Date of Birth')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="dob" type="date" class="form-control <?php if ($errors->has('dob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dob'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('confirm')); ?>" name="dob" autocomplete="new-password">
                            </div>
                            <?php if ($errors->has('dob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dob'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        
                        <div class="form-group row">
                            <label for="gender" class="col-md-4 col-form-label text-md-right"><?php echo e(__('gender')); ?></label>
                            <div class="col-md-6 col-form-label text-md-left">
                                <span for="male">male</span> <input type="radio" name="gender" value="male">
                                <span for="female">female</span> <input type="radio" name="gender" value="female">
                            </div>
                            <?php if ($errors->has('gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gender'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        
                        
                        
                        <div class="form-group row">
                            <label for="phone" class="col-md-4 col-form-label text-md-right"><?php echo e(__('phone')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="phone" type="text" class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('phone')); ?>" name="phone" autocomplete="phone">
                            </div>
                            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>

                        <div class="form-group row">
                            <label for="company_name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('company name')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="company_name" type="text" class="form-control <?php if ($errors->has('company_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('company_name')); ?>" name="company_name">
                            </div>
                            <?php if ($errors->has('company_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company_name'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        
                        <div class="form-group row">
                            <label for="location" class="col-md-4 col-form-label text-md-right"><?php echo e(__('address')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="location" type="text" class="form-control <?php if ($errors->has('location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('location')); ?>" name="location">
                            </div>
                            <?php if ($errors->has('location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        
                        <div class="form-group row">
                            <label for="employee_type" class="col-md-4 col-form-label text-md-right"><?php echo e(__('employee type')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="employee_type" type="text" class="form-control <?php if ($errors->has('employee_type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('employee_type'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('employee_type')); ?>" name="employee_type" >
                            </div>
                            <?php if ($errors->has('employee_type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('employee_type'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        
                        
                        
                        <div class="form-group row">
                            <label for="occupation" class="col-md-4 col-form-label text-md-right"><?php echo e(__('occupation')); ?></label>
                            
                            <div class="col-md-6">
                                <textarea name="occupation" id="occupation" class="form-control <?php if ($errors->has('occupation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('occupation'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"><?php echo e(old('occupation')); ?></textarea>
                            </div>
                            <?php if ($errors->has('occupation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('occupation'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        
                        <div class="form-group row">
                            <label for="study_place" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Study Place')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="study_place" type="text" class="form-control <?php if ($errors->has('study_place')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('study_place'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('study_place')); ?>" name="study_place" >
                            </div>
                            <?php if ($errors->has('study_place')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('study_place'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        
                        <div class="form-group row">
                            <label for="position" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Position')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="position" type="text" class="form-control <?php if ($errors->has('position')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('position'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('position')); ?>" name="position" >
                            </div>
                            <?php if ($errors->has('position')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('position'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        
                        <div class="form-group row">
                            <label for="dev_ide" class="col-md-4 col-form-label text-md-right"><?php echo e(__('What is you Development Environment?')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="dev_ide" type="text" class="form-control <?php if ($errors->has('dev_ide')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dev_ide'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('dev_ide')); ?>" name="dev_ide" >
                            </div>
                            <?php if ($errors->has('dev_ide')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dev_ide'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>

                        <div class="form-group row">
                            <label for="about_devcon" class="col-md-4 col-form-label text-md-right"><?php echo e(__('About DevCon?')); ?></label>
                            
                            <div class="col-md-6">
                                <textarea name="about_devcon" class="form-control <?php if ($errors->has('about_devcon')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('about_devcon'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="about_devcon"><?php echo e(old('about_devcon')); ?></textarea>
                            </div>
                            <?php if ($errors->has('about_devcon')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('about_devcon'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        
                        <div class="form-group row">
                            <label for="previous_year" class="col-md-4 col-form-label text-md-right"><?php echo e(__('previous year?')); ?></label>
                            
                            <div class="col-md-6">
                                <textarea name="previous_year" class="form-control <?php if ($errors->has('about_devcon')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('about_devcon'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="previous_year"><?php echo e(old('about_devcon')); ?></textarea>
                            </div>
                            <?php if ($errors->has('previous_year')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('previous_year'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aungkhantzaw\Documents\coding\devcon_2019\resources\views/auth/register.blade.php ENDPATH**/ ?>