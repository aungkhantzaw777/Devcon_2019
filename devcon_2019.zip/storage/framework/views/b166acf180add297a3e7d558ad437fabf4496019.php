<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>success</title>
    <link rel="stylesheet" href="css/app.css">
</head>
<body>
    <div class="container">
        <div class="text-center">successfully regiser <a href="/">&laquo;go back</a> </div>
        
    </div>
</body>
</html><?php /**PATH C:\Users\aungkhantzaw\Documents\coding\devcon_2019\resources\views/success.blade.php ENDPATH**/ ?>