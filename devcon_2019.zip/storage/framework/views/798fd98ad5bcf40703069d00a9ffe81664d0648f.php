<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Dev Con</title>
    
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/fonts/ionicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/fontawesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/login.min.css')); ?>">
</head>

<body>
    <div class="login-clean" id="app" style="min-height: 100vh;">
        <form method="post" action="/dev_con/login">
            <?php echo csrf_field(); ?>
            <h2 class="sr-only">Admin Login Form</h2>
            <div class="illustration"><i class="icon ion-ios-navigate"></i></div>
            
            <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email"></div>
            <div class="input-group">
                
                <input :type="eyes.type" class="form-control" name="password" placeholder="Password" aria-label="password" aria-describedby="basic-addon2">
                <div class="input-group-append cursor-pointer" @click="eyesMethod">
                    <span class="input-group-text" id="basic-addon2"><i :class="eyes.icon"></i></span>
                </div>
                
            </div>
            <div class="form-group"><button class="btn btn-primary btn-block" type="submit">Log In</button></div><a class="forgot" href="#">Forgot your email or password?</a></form>
        </div>
        <script src="<?php echo e(asset('js/login.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/js/jquery.min.js')); ?>"></script>
        
    </body>
    
    </html><?php /**PATH C:\Users\aungkhantzaw\Documents\coding\devcon_2019\resources\views/admin/login.blade.php ENDPATH**/ ?>