<?php $__env->startComponent('mail::message'); ?>
# Congratuation Your Registration is success

hi, ko <?php echo e($user->username); ?>, your ticket id is : <?php echo e($user->ticket_id); ?>


<?php $__env->startComponent('mail::button', ['url' => '/home']); ?>
confrim email
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\aungkhantzaw\Documents\coding\devcon_2019\resources\views/emails/user-register.blade.php ENDPATH**/ ?>