<?php echo e($slot); ?>

<?php /**PATH C:\Users\aungkhantzaw\Documents\coding\devcon_2019\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>