<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Auth::routes();



Route::get('/home', 'HomeController@index')->name('home');

Route::resource('/ticket','TicketController')->middleware('auth');

Route::get('register','AuthUserController@register')->name('register');
Route::get('success','AuthUserController@success')->name('success');
Route::post('register','AuthUserController@postRegister')->name('register');
Route::get('login','AuthUserController@login')->name('login');
Route::post('login','AuthUserController@postLogin')->name('loginPost');